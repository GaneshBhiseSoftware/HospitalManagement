package com.avsoft.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalMangmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalMangmentApplication.class, args);
	}

}
