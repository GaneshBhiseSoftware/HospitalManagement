package com.avsoft.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.avsoft.demo.entity.Doctor;
import com.avsoft.demo.service.DoctorServicer;

@RestController
public class DoctorCOntroller {
	@Autowired
	DoctorServicer mbbsDoctorServiceImpl;
	
	
	@Autowired
	DoctorServicer bamsDoctorServiceImpl;
	

	@PostMapping("doctor")
	public String addDoctor(@RequestBody Doctor doctor) {
		
		if(doctor.getEducation().equals("MBBS"))
			mbbsDoctorServiceImpl.saveDoctor(doctor);
		
		
		if(doctor.getEducation().equals("BAMS"))
			bamsDoctorServiceImpl.saveDoctor(doctor);
		
		return "added";
	}

}
