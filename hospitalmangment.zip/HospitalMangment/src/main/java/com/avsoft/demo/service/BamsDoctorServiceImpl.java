package com.avsoft.demo.service;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.avsoft.demo.entity.Doctor;

@Service
public class BamsDoctorServiceImpl implements DoctorServicer {

	@Override
	public void saveDoctor(Doctor d) {
		// TODO Auto-generated method stub
		System.out.println("bams doctor added");
	}

	@Override
	public void deleteDoctor(int dId) {
		// TODO Auto-generated method stub
		
	}

}
