package com.avsoft.demo.service;

import com.avsoft.demo.entity.Doctor;

public interface DoctorServicer {
 
	public void saveDoctor(Doctor d);
	
	public void deleteDoctor(int dId);
	
	
	
}
