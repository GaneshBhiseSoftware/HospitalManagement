package com.avsoft.demo.service;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.avsoft.demo.entity.Doctor;
@Service

public class MbbsDoctorServiceImpl implements DoctorServicer {

	@Override
	public void saveDoctor(Doctor d) {
		// TODO Auto-generated method stub
		System.out.println("mbbs doctor addeds");
	}

	@Override
	public void deleteDoctor(int dId) {
		// TODO Auto-generated method stub
		
	}

}
